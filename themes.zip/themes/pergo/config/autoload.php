<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$autoload['packages'] = array();
$autoload['libraries'] = array();
$autoload['drivers'] = array();
$autoload['helper'] = array();
$autoload['config'] = array();
$autoload['language'] = array('pergo');
$autoload['model'] = array();
