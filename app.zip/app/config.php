<?php
//Config Database
define('DB_HOST', 'localhost');
define('DB_USER', '');
define('DB_PASS', '');
define('DB_NAME', '');
define('TIMEZONE', 'Africa/Abidjan');
define('ENCRYPTION_KEY', '25c7aa4e16660d8a972c9953239c055b');
